import numpy as np
from scipy import optimize
try:
    #a = np.arange(6).reshape(6,1)# assume karray
                                
    b = np.arange(24).reshape((6,4)) # assume eigval_array
    #c= np.zeros(30).reshape((6,5)) # Personal note: np.zeros(size), size is the product of dimensions!
    #c = np.concatenate((b,a),axis=1)
    d  = np.arange(6).reshape(1,6,1)
    a = np.arange(10)
    a[::2]+=3 # add to every 2nd item
    def somefunc(x):
        return x +4
    for x in range(5):
        somefunc = somefunc(x) 
        interval = [1,4]
        rootsol = optimize.root(somefunc,interval)
        print rootsol

        
except Exception as e:
    print (str(e))